
chrome.runtime.onMessage.addListener((request,sender,sendResponse) =>{
    
    if(request && request.message =='addresult'){
	var engine = whichSearchEngine();
	var rs = null;
	var info =[];
	if(engine =='google'){
	    rs = getGoogleResult();	    	    
	}else if(engine =='bing'){
	    rs = getBingResult();
	}else if(engine =='duckduckgo'){
	    rs = getDuckResult();
	}else{
	    // do nothing
	}
	
	if(rs == null){
	    sendResponse({error: 'stop'});
	}else{
	    var links = rs;
	    links.forEach( e => {
		var h = getHost(e);
		if(h != null && h !='')
		    if(!except(h))
			info.push(h);
	    });
	    sendResponse({hosts: info});
	}
    }
    
});

function except(url){
    if(url =='www.bing.com'   ||
       url =='duckduckgo.com' ||
       url =='www.google.ca'  ||
       url =='www.google.com'){
	return true;
    }else
	return false;
}


function whichSearchEngine(){
    var m = getHost(document.URL);
    if(m =='www.bing.com')
	return 'bing';
    else if(m == 'www.google.ca' || m =='www.google.com')
	return 'google';
    else if(m == 'duckduckgo.com')
	return 'duckduckgo';
    else
	return 'unknown';
}

function getGoogleResult() {
    var tmp =[];
    var r = document.getElementById('search');
    try{
	r.querySelectorAll('a').forEach(e => {
	    tmp.push(e.href);
	});
    }catch{}  
    return tmp;
}

function getBingResult() {
    var tmp = [];
    var r  = document.getElementById('b_results');
    try{
	r.querySelectorAll('cite').forEach(e => {
	    tmp.push(e.innerText);
	});
	r.querySelectorAll('a').forEach(e => { tmp.push(e.href)});
    }catch{}
    return tmp;
}

function getDuckResult() {
    var tmp = [];
    try{
	var r = document.getElementsByClassName('results--main')[0];
	r.querySelectorAll('a').forEach(e => { tmp.push(e.href)});
    }catch{}
    
    return tmp;
    
}

function getHost(link){
    var url ='';
    try{
	url = new URL(link);
    }catch{
	return '';
    }   
    return url.hostname;
}



